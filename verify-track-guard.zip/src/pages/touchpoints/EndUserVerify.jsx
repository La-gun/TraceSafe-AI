import React from "react";
import { Link } from "react-router-dom";
import Navbar from "../../components/landing/Navbar";
import Footer from "../../components/landing/Footer";
import { motion } from "framer-motion";
import { User, ArrowLeft, CheckCircle, Smartphone, ShieldCheck, Eye, AlertTriangle } from "lucide-react";

const steps = [
  {
    icon: Smartphone,
    title: "NFC Tap Verification",
    desc: "The end user taps the product tag with any standard NFC-enabled smartphone — no app download required. The NDEF URL opens a secure, lightweight web page that is loaded from the backend in real time.",
  },
  {
    icon: ShieldCheck,
    title: "Cryptographic Authentication",
    desc: "The Secure Dynamic Messaging (SDM) payload is validated server-side against the registered tag identity. Anti-cloning and replay detection checks run automatically — confirming the tag has not been duplicated.",
  },
  {
    icon: Eye,
    title: "Redacted Audit Trail",
    desc: "The end user sees a clean, redacted provenance summary: manufacturer, batch, authorised import status, and supply chain stage confirmations. Sensitive commercial route details are hidden — only trust-relevant information is shown.",
  },
  {
    icon: AlertTriangle,
    title: "Anomaly Check Before Display",
    desc: "Before rendering the result, the system checks for recall status, suspicious scan patterns, first-scan state, and authorised chain continuity. If any check fails, the user receives a clear warning and a NAFDAC reporting prompt.",
  },
];

const facts = [
  "No app download — works with any NFC-enabled smartphone",
  "Cryptographic SDM validation on every tap",
  "Anti-cloning and replay protection built in",
  "Recall status checked before displaying result",
  "Redacted view protects commercial data",
  "Suspicious result prompts NAFDAC complaint reporting",
];

const verificationStates = [
  { label: "Authentic", desc: "Tag verified, authorised chain confirmed, no recall", color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" },
  { label: "Suspicious", desc: "Chain incomplete, geo mismatch, or repeat scan detected", color: "text-amber-400 bg-amber-500/10 border-amber-500/20" },
  { label: "Counterfeit Alert", desc: "Cryptographic validation failed or tag cloning detected", color: "text-red-400 bg-red-500/10 border-red-500/20" },
  { label: "Recalled", desc: "Batch subject to active recall — do not use", color: "text-red-400 bg-red-500/10 border-red-500/20" },
];

export default function EndUserVerify() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      <section className="pt-32 pb-16 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-emerald-500/8 rounded-full blur-[120px]" />
        <div className="max-w-5xl mx-auto relative z-10">
          <Link to="/Home#platform" className="inline-flex items-center gap-2 text-xs text-emerald-400/60 hover:text-emerald-400 mb-8 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Platform Overview
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <User className="w-7 h-7 text-emerald-400" />
            </div>
            <div>
              <span className="text-xs font-mono text-emerald-500/50">Stage 05</span>
              <h1 className="text-3xl sm:text-5xl font-bold text-white">End-User Verify</h1>
            </div>
          </div>
          <p className="text-gray-400 text-lg max-w-3xl leading-relaxed">
            The final moment of truth. A single tap by the end user — patient, healthcare worker, or consumer — confirms authenticity and shows whether the product followed an authorised route from manufacturer to their hands.
          </p>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-white/[0.06] h-72 sm:h-96">
            <img
              src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=1200&q=80"
              alt="Consumer scanning product with NFC phone"
              className="w-full h-full object-cover opacity-50"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#060B18] via-[#060B18]/40 to-transparent" />
            <div className="absolute bottom-8 left-8">
              <span className="text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-full">
                End-User Verification
              </span>
              <p className="text-white font-semibold text-lg mt-2">One tap confirms authenticity</p>
              <p className="text-gray-400 text-sm">No app download — works on any NFC phone</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">How It Works</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 hover:border-emerald-500/15 transition-all"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-4">
                  <step.icon className="w-4 h-4 text-emerald-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Verification states */}
      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">Possible Verification Results</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {verificationStates.map((state, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.06 }}
                className={`border rounded-2xl p-5 ${state.color}`}
              >
                <p className="font-semibold mb-1">{state.label}</p>
                <p className="text-xs opacity-80">{state.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white mb-6">Key Capabilities at This Stage</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {facts.map((fact, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <span className="text-sm text-gray-400">{fact}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1526256262350-7da7584cf5eb?w=800&q=80" alt="NFC phone tap medicine" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">NFC Tap Result</p>
              <p className="text-gray-400 text-xs">Instant authentication in the field</p>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=800&q=80" alt="Healthcare worker verifying medicine" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Healthcare Verification</p>
              <p className="text-gray-400 text-xs">Nurses and pharmacists verify at point of care</p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="px-6 pb-24">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 bg-gradient-to-r from-emerald-500/[0.06] to-transparent border border-emerald-500/10 rounded-2xl p-6">
          <div>
            <p className="text-white font-semibold mb-1">Ready to see the full platform in action?</p>
            <p className="text-gray-500 text-sm">Book a demo to see a live end-to-end traceability walkthrough.</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <Link to="/touchpoints/retail-receipt" className="text-xs text-gray-500 hover:text-gray-300 transition-colors flex items-center">← Retail Receipt</Link>
            <Link to="/Contact" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium px-5 py-2.5 rounded-full transition-colors">
              Book a Demo
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}