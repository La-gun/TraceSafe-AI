import React from "react";
import { Link } from "react-router-dom";
import Navbar from "../../components/landing/Navbar";
import Footer from "../../components/landing/Footer";
import { motion } from "framer-motion";
import { Ship, ArrowRight, ArrowLeft, CheckCircle, Scan, AlertTriangle, FileCheck, Globe } from "lucide-react";

const steps = [
  {
    icon: Scan,
    title: "Parent Tag Tap",
    desc: "Customs or port operators tap the shipment or pallet parent tag with a standard NFC-enabled device. A single tap resolves all linked child items via the aggregation graph — no need to scan every unit individually.",
  },
  {
    icon: FileCheck,
    title: "Customs Status Propagation",
    desc: "The backend verifies the parent object, records the port receipt event with timestamp and operator identity, and propagates a derived arrival status to all linked child items simultaneously.",
  },
  {
    icon: AlertTriangle,
    title: "Exception Handling",
    desc: "Seal breaks, quantity mismatches, hold orders, or customs flags are written as separate exception events in the trace ledger — creating a transparent audit record for NAFDAC and border enforcement teams.",
  },
  {
    icon: Globe,
    title: "Import Channel Assurance",
    desc: "Every shipment arriving through an authorised importer is stamped with a verified port-of-entry event. Products that bypass this checkpoint are immediately flagged as having an incomplete chain of custody.",
  },
];

const facts = [
  "One parent tap updates all linked child items",
  "Customs state propagated instantly to entire shipment",
  "Seal break and mismatch events written as separate alerts",
  "Hold and quarantine states applied at shipment level",
  "Port operator identity and device fingerprint recorded",
  "Products without port receipt flagged as high risk",
];

export default function PortOfEntry() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      <section className="pt-32 pb-16 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-teal-500/6 rounded-full blur-[120px]" />
        <div className="max-w-5xl mx-auto relative z-10">
          <Link to="/Home#platform" className="inline-flex items-center gap-2 text-xs text-emerald-400/60 hover:text-emerald-400 mb-8 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Platform Overview
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center">
              <Ship className="w-7 h-7 text-teal-400" />
            </div>
            <div>
              <span className="text-xs font-mono text-teal-500/50">Stage 02</span>
              <h1 className="text-3xl sm:text-5xl font-bold text-white">Port of Entry</h1>
            </div>
          </div>
          <p className="text-gray-400 text-lg max-w-3xl leading-relaxed">
            Nigeria's ports and border crossings are critical chokepoints in the pharmaceutical supply chain. A single verified port receipt event anchors the entire authorised import chain — and products that skip this step are automatically flagged as high-risk.
          </p>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-white/[0.06] h-72 sm:h-96">
            <img
              src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=1200&q=80"
              alt="Port of entry cargo inspection"
              className="w-full h-full object-cover opacity-50"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#060B18] via-[#060B18]/40 to-transparent" />
            <div className="absolute bottom-8 left-8">
              <span className="text-xs font-medium text-teal-400 bg-teal-500/10 border border-teal-500/20 px-3 py-1.5 rounded-full">
                Import Verification
              </span>
              <p className="text-white font-semibold text-lg mt-2">One tap verifies the entire shipment</p>
              <p className="text-gray-400 text-sm">Apapa, Tin Can, and inland border checkpoints</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">How It Works</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 hover:border-teal-500/15 transition-all"
              >
                <div className="w-9 h-9 rounded-xl bg-teal-500/10 flex items-center justify-center mb-4">
                  <step.icon className="w-4 h-4 text-teal-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white mb-6">Key Capabilities at This Stage</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {facts.map((fact, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-teal-400 mt-0.5 shrink-0" />
                  <span className="text-sm text-gray-400">{fact}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=800&q=80" alt="Cargo containers at port" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Shipment Receipt</p>
              <p className="text-gray-400 text-xs">Parent-level NFC tap at port</p>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=800&q=80" alt="Customs inspection" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Exception Recording</p>
              <p className="text-gray-400 text-xs">Seal breaks & holds logged immediately</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-24">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6">
          <div className="flex gap-6">
            <Link to="/touchpoints/manufacture" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">← Manufacture</Link>
          </div>
          <div className="text-center sm:text-right">
            <p className="text-xs text-gray-500 mb-1">Next Stage</p>
            <p className="text-white font-semibold">Wholesale Transfer →</p>
            <p className="text-gray-500 text-sm">De-aggregate and re-assign inventory to distributors</p>
          </div>
          <Link to="/touchpoints/wholesale-transfer" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium px-5 py-2.5 rounded-full transition-colors shrink-0">
            Next Stage <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}