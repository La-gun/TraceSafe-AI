import React from "react";
import { Link } from "react-router-dom";
import Navbar from "../../components/landing/Navbar";
import Footer from "../../components/landing/Footer";
import { motion } from "framer-motion";
import { Warehouse, ArrowRight, ArrowLeft, CheckCircle, Layers, GitMerge, Users, MapPin } from "lucide-react";

const steps = [
  {
    icon: Layers,
    title: "De-aggregation",
    desc: "When a distributor splits a pallet to send partial inventory to multiple outlets, a de-aggregation event breaks the parent binding. Each child item is released for independent tracking before being re-bound to new parent structures.",
  },
  {
    icon: GitMerge,
    title: "Re-aggregation",
    desc: "Released items are re-bound into new case or pallet structures for onward transfer. The backend creates a new aggregation graph with a new custodian identity — ensuring child ownership is always exact and auditable.",
  },
  {
    icon: Users,
    title: "Custody Change Recording",
    desc: "Every transfer event records the sending partner, receiving partner, transfer location, timestamp, and operator identity. The ownership history is preserved indefinitely in the immutable trace ledger.",
  },
  {
    icon: MapPin,
    title: "Diversion Signal Detection",
    desc: "When goods appear in a geographic zone inconsistent with the authorised distribution route, the anomaly engine raises a diversion signal. NAFDAC field teams can be alerted for targeted inspection.",
  },
];

const facts = [
  "De-aggregation ensures child ownership remains exact",
  "Re-aggregation creates new audit-tracked parent structures",
  "Every custody change recorded with full partner identity",
  "Geographic route compliance monitored automatically",
  "Diversion signals generated for out-of-route movements",
  "SLA reporting available for distribution partners",
];

export default function WholesaleTransfer() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      <section className="pt-32 pb-16 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-cyan-500/6 rounded-full blur-[120px]" />
        <div className="max-w-5xl mx-auto relative z-10">
          <Link to="/Home#platform" className="inline-flex items-center gap-2 text-xs text-emerald-400/60 hover:text-emerald-400 mb-8 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Platform Overview
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
              <Warehouse className="w-7 h-7 text-cyan-400" />
            </div>
            <div>
              <span className="text-xs font-mono text-cyan-500/50">Stage 03</span>
              <h1 className="text-3xl sm:text-5xl font-bold text-white">Wholesale Transfer</h1>
            </div>
          </div>
          <p className="text-gray-400 text-lg max-w-3xl leading-relaxed">
            Nigeria's wholesale and distribution tier is where most supply chain integrity breaks down. TraceGuard tracks every custody change, split shipment, and re-aggregation event — making diversion and grey-market activity visible in real time.
          </p>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-white/[0.06] h-72 sm:h-96">
            <img
              src="https://images.unsplash.com/photo-1553413077-190dd305871c?w=1200&q=80"
              alt="Pharmaceutical warehouse distribution"
              className="w-full h-full object-cover opacity-50"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#060B18] via-[#060B18]/40 to-transparent" />
            <div className="absolute bottom-8 left-8">
              <span className="text-xs font-medium text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-3 py-1.5 rounded-full">
                Distribution Tracking
              </span>
              <p className="text-white font-semibold text-lg mt-2">Every split and transfer recorded</p>
              <p className="text-gray-400 text-sm">Custody integrity preserved at every handoff</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">How It Works</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 hover:border-cyan-500/15 transition-all"
              >
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-4">
                  <step.icon className="w-4 h-4 text-cyan-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white mb-6">Key Capabilities at This Stage</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {facts.map((fact, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
                  <span className="text-sm text-gray-400">{fact}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1586528116493-a029325540fa?w=800&q=80" alt="Warehouse stock management" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Inventory Management</p>
              <p className="text-gray-400 text-xs">De-aggregate and re-aggregate with precision</p>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&q=80" alt="Distribution route monitoring" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Route Compliance</p>
              <p className="text-gray-400 text-xs">Diversion signals flagged automatically</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-24">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6">
          <div className="flex gap-6">
            <Link to="/touchpoints/port-of-entry" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">← Port of Entry</Link>
          </div>
          <div className="text-center sm:text-right">
            <p className="text-xs text-gray-500 mb-1">Next Stage</p>
            <p className="text-white font-semibold">Retail Receipt →</p>
            <p className="text-gray-500 text-sm">Completing the authorised chain at pharmacy level</p>
          </div>
          <Link to="/touchpoints/retail-receipt" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium px-5 py-2.5 rounded-full transition-colors shrink-0">
            Next Stage <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}