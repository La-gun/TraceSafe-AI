import React from "react";
import { Link } from "react-router-dom";
import Navbar from "../../components/landing/Navbar";
import Footer from "../../components/landing/Footer";
import { motion } from "framer-motion";
import { Store, ArrowRight, ArrowLeft, CheckCircle, MapPin, ShieldCheck, Package, Bell } from "lucide-react";

const steps = [
  {
    icon: Package,
    title: "Receipt Confirmation",
    desc: "Retail operators — pharmacies, hospitals, or registered outlets — scan received stock to confirm receipt and trigger a retail receipt event. This completes the authorised chain from manufacturer to point of dispensing.",
  },
  {
    icon: MapPin,
    title: "Outlet Registration",
    desc: "Each retail outlet is registered in the partner master data with location, license status, and operator identity. Scans from unregistered outlets are automatically flagged as suspicious in the NAFDAC dashboard.",
  },
  {
    icon: ShieldCheck,
    title: "Authorised Chain Completion",
    desc: "The retail receipt event is the final link in the authorised chain before end-user verification. Products that reach consumers without a retail receipt event are classified as having an incomplete provenance trail.",
  },
  {
    icon: Bell,
    title: "Anomaly Alerts",
    desc: "If a product arrives at a retail outlet that was not part of the expected distribution route — or if stock appears in an unregistered location — the anomaly engine generates an immediate alert for NAFDAC field action.",
  },
];

const facts = [
  "Retail receipt event completes the authorised supply chain",
  "Every registered outlet verified against partner master data",
  "Unregistered outlet scans flagged immediately",
  "Point-of-sale events captured for audit and analytics",
  "Batch-level watchlists enforced at retail scan time",
  "Recall notices propagated to affected retail stock instantly",
];

export default function RetailReceipt() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      <section className="pt-32 pb-16 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-amber-500/6 rounded-full blur-[120px]" />
        <div className="max-w-5xl mx-auto relative z-10">
          <Link to="/Home#platform" className="inline-flex items-center gap-2 text-xs text-emerald-400/60 hover:text-emerald-400 mb-8 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Platform Overview
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
              <Store className="w-7 h-7 text-amber-400" />
            </div>
            <div>
              <span className="text-xs font-mono text-amber-500/50">Stage 04</span>
              <h1 className="text-3xl sm:text-5xl font-bold text-white">Retail Receipt</h1>
            </div>
          </div>
          <p className="text-gray-400 text-lg max-w-3xl leading-relaxed">
            The pharmacy, hospital, or registered retail outlet is the last gatekeeper before a product reaches the end user. A retail receipt event completes the authorised chain and enables NAFDAC to verify that every dispensed product followed a legitimate route.
          </p>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-white/[0.06] h-72 sm:h-96">
            <img
              src="https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=1200&q=80"
              alt="Pharmacy retail dispensing"
              className="w-full h-full object-cover opacity-50"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#060B18] via-[#060B18]/40 to-transparent" />
            <div className="absolute bottom-8 left-8">
              <span className="text-xs font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-full">
                Point of Dispensing
              </span>
              <p className="text-white font-semibold text-lg mt-2">Authorised chain completed at the pharmacy</p>
              <p className="text-gray-400 text-sm">Every outlet registered, every batch tracked</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">How It Works</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 hover:border-amber-500/15 transition-all"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center mb-4">
                  <step.icon className="w-4 h-4 text-amber-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white mb-6">Key Capabilities at This Stage</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {facts.map((fact, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                  <span className="text-sm text-gray-400">{fact}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&q=80" alt="Pharmacy stock check" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Stock Verification</p>
              <p className="text-gray-400 text-xs">NFC tap confirms authorised receipt</p>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1585435557343-3b092031a831?w=800&q=80" alt="Pharmacy dispensing counter" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Outlet Registration</p>
              <p className="text-gray-400 text-xs">Licensed outlets tracked in partner master data</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-24">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6">
          <div className="flex gap-6">
            <Link to="/touchpoints/wholesale-transfer" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">← Wholesale Transfer</Link>
          </div>
          <div className="text-center sm:text-right">
            <p className="text-xs text-gray-500 mb-1">Final Stage</p>
            <p className="text-white font-semibold">End-User Verify →</p>
            <p className="text-gray-500 text-sm">Consumer tap confirms authenticity in seconds</p>
          </div>
          <Link to="/touchpoints/end-user-verify" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium px-5 py-2.5 rounded-full transition-colors shrink-0">
            Final Stage <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}