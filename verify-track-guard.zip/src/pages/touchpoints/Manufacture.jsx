import React from "react";
import { Link } from "react-router-dom";
import Navbar from "../../components/landing/Navbar";
import Footer from "../../components/landing/Footer";
import { motion } from "framer-motion";
import { Factory, ArrowRight, ArrowLeft, CheckCircle, Cpu, Tag, Database, Lock, QrCode, Layers } from "lucide-react";

const steps = [
  {
    icon: Tag,
    title: "Tag Personalisation",
    desc: "Each NTAG 424 DNA tag is personalised at the factory with a unique cryptographic identity, item serial, and secure NDEF URL template bound to the product's digital twin in the backend registry.",
  },
  {
    icon: Database,
    title: "Batch & Serial Records",
    desc: "Production records are created capturing product name, batch number, manufacture date, factory line, shift, and shelf life. These form the master data anchor for all downstream traceability events.",
  },
  {
    icon: Layers,
    title: "Aggregation Binding",
    desc: "Commissioned units are bound to parent case, pallet, and shipment objects. The aggregation graph is locked once packing is complete — enabling single-tap bulk updates at logistics touchpoints.",
  },
  {
    icon: Lock,
    title: "Key Management",
    desc: "Cryptographic keys are provisioned via a KMS/HSM-backed service with per-tenant separation and controlled rotation. No keys ever reside in application code or portable media.",
  },
];

const facts = [
  "Each unit gets a globally unique NTAG 424 DNA identity",
  "Secure Dynamic Messaging (SDM) enables per-tap cryptographic verification",
  "Digital twin created instantly at commissioning",
  "Aggregation graph locked before goods leave the factory",
  "Full batch and serial records created for audit and recall readiness",
  "Key rotation managed without interrupting field operations",
];

export default function Manufacture() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-emerald-500/6 rounded-full blur-[120px]" />
        <div className="max-w-5xl mx-auto relative z-10">
          <Link to="/Home#platform" className="inline-flex items-center gap-2 text-xs text-emerald-400/60 hover:text-emerald-400 mb-8 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Platform Overview
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <Factory className="w-7 h-7 text-emerald-400" />
            </div>
            <div>
              <span className="text-xs font-mono text-emerald-500/50">Stage 01</span>
              <h1 className="text-3xl sm:text-5xl font-bold text-white">Manufacture</h1>
            </div>
          </div>
          <p className="text-gray-400 text-lg max-w-3xl leading-relaxed">
            The traceability chain begins at the factory floor. Every sellable unit is commissioned with a secure digital identity before it leaves the production line — making counterfeiting structurally difficult from day one.
          </p>
        </div>
      </section>

      {/* Hero image */}
      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-white/[0.06] h-72 sm:h-96">
            <img
              src="https://images.unsplash.com/photo-1565043666747-69f6646db940?w=1200&q=80"
              alt="Consumer goods manufacturing facility"
              className="w-full h-full object-cover opacity-60"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#060B18] via-[#060B18]/40 to-transparent" />
            <div className="absolute bottom-8 left-8">
              <span className="text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-full">
                Factory Commissioning
              </span>
              <p className="text-white font-semibold text-lg mt-2">Every unit gets a secure digital identity</p>
              <p className="text-gray-400 text-sm">before it leaves the production line</p>
            </div>
          </div>
        </div>
      </section>

      {/* How it works steps */}
      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">How It Works</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 hover:border-emerald-500/15 transition-all"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-4">
                  <step.icon className="w-4.5 h-4.5 text-emerald-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Key facts */}
      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white mb-6">Key Capabilities at This Stage</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {facts.map((fact, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <span className="text-sm text-gray-400">{fact}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Secondary image */}
      <section className="px-6 pb-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=800&q=80" alt="NFC tag commissioning" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">NFC Tag Commissioning</p>
              <p className="text-gray-400 text-xs">Unique identity per unit</p>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.06] h-56">
            <img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&q=80" alt="Product batch records" className="w-full h-full object-cover opacity-50" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060B18] via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white text-sm font-semibold">Batch Record Creation</p>
              <p className="text-gray-400 text-xs">Full audit-ready data at source</p>
            </div>
          </div>
        </div>
      </section>

      {/* Next stage CTA */}
      <section className="px-6 pb-24">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6">
          <div>
            <p className="text-xs text-gray-500 mb-1">Next Stage</p>
            <p className="text-white font-semibold">Port of Entry →</p>
            <p className="text-gray-500 text-sm">Parent-level tap verifies shipments at customs</p>
          </div>
          <Link to="/touchpoints/port-of-entry" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium px-5 py-2.5 rounded-full transition-colors shrink-0">
            Next Stage <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}