import React from "react";
import Navbar from "../components/landing/Navbar";
import Footer from "../components/landing/Footer";
import { motion } from "framer-motion";
import {
  ShieldCheck,
  Route,
  Brain,
  Gavel,
  Scan,
  Layers,
  MapPin,
  AlertTriangle,
  FileSearch,
  Users,
  BarChart3,
  Repeat,
} from "lucide-react";

const solutions = [
  {
    icon: ShieldCheck,
    title: "Product Authentication",
    headline: "NTAG 424 DNA Secure Identity",
    desc: "Every consumer unit gets a unique digital twin linked to a secure NTAG 424 DNA response. Supports item-level authenticity, repeat-scan intelligence, and anti-cloning detection — far harder to defeat than static labels or plain QR codes.",
    features: [
      "Secure Dynamic Messaging (SDM) validation",
      "Per-tap cryptographic authentication",
      "Anti-cloning and replay detection",
      "Key versioning and rotation management",
    ],
  },
  {
    icon: Route,
    title: "Supply Chain Traceability",
    headline: "GS1 EPCIS-Style Event Capture",
    desc: "Each touchpoint writes an immutable business event — from factory commissioning through port receipt, wholesale transfer, retail receipt to end-user verification. Full parent-child aggregation for cartons, pallets, and shipments.",
    features: [
      "Event-driven traceability ledger",
      "Aggregation and de-aggregation engine",
      "Ownership history and custody tracking",
      "Recall and quarantine state management",
    ],
  },
  {
    icon: Brain,
    title: "Field Surveillance Intelligence",
    headline: "Anomaly Detection & Diversion Signals",
    desc: "Transform scan data into actionable intelligence. Suspicious-scan heat maps, repeat-scan alerts, geo-mismatch detection, and diversion signals help regulators target inspections instead of relying on broad sweeps.",
    features: [
      "Real-time scan anomaly scoring",
      "Geographic diversion heat maps",
      "Repeat-scan pattern detection",
      "Batch-level risk watchlists",
    ],
  },
  {
    icon: Gavel,
    title: "Enforcement Workflow",
    headline: "Case Management & Evidence Trail",
    desc: "Turn intelligence alerts into operational action. Inspector workflows for verification, evidence capture, hold/quarantine recommendations, and escalation. Every action recorded in a tamper-evident audit stream.",
    features: [
      "Inspector verification workflow",
      "Hold and quarantine triggers",
      "Evidentiary trail for prosecution",
      "Escalation and case management",
    ],
  },
];

const additionalCapabilities = [
  { icon: Scan, title: "End-User Verification", desc: "Lightweight web page from NDEF URL tap showing redacted provenance" },
  { icon: Layers, title: "Parent-Child Aggregation", desc: "One parent tap updates all linked items without storing history on tag" },
  { icon: MapPin, title: "Geo-Fence Monitoring", desc: "Track products across authorised zones and flag route deviations" },
  { icon: AlertTriangle, title: "Recall Management", desc: "Instant recall propagation to all affected units in the chain" },
  { icon: FileSearch, title: "Regulator Reporting", desc: "Regulator-ready dashboards and export-ready compliance reports for any governed category" },
  { icon: Users, title: "Partner Onboarding", desc: "Outlet registration, access control, and partner master data management" },
  { icon: BarChart3, title: "Analytics & KPIs", desc: "Operational scan analytics, throughput metrics, and SLA monitoring" },
  { icon: Repeat, title: "ERP / WMS Integration", desc: "APIs for enterprise system integration at manufacturer and distributor level" },
];

export default function Solutions() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 px-6 relative">
        <div className="absolute top-1/3 left-1/3 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[120px]" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="text-xs font-medium text-emerald-400 tracking-widest uppercase">
            Solutions
          </span>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-5">
            Enforcement Infrastructure,{" "}
            <span className="text-emerald-400">Not Stickers</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            A complete platform that helps regulators and enterprises move from reactive mop-up to
            targeted, evidence-led action across Nigeria's regulated consumer goods
            and supply chains.
          </p>
        </div>
      </section>

      {/* Core Solutions */}
      <section className="pb-24 px-6">
        <div className="max-w-6xl mx-auto space-y-8">
          {solutions.map((sol, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8 sm:p-10 hover:border-emerald-500/15 transition-all"
            >
              <div className="flex flex-col lg:flex-row gap-8">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                      <sol.icon className="w-5 h-5 text-emerald-400" />
                    </div>
                    <span className="text-xs font-medium text-emerald-400/60 uppercase tracking-wider">
                      {sol.title}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">{sol.headline}</h3>
                  <p className="text-gray-400 leading-relaxed">{sol.desc}</p>
                </div>
                <div className="lg:w-80 shrink-0">
                  <div className="bg-white/[0.02] rounded-2xl p-5 border border-white/[0.04]">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-3">
                      Key Capabilities
                    </p>
                    <ul className="space-y-2.5">
                      {sol.features.map((f, j) => (
                        <li key={j} className="flex items-start gap-2.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                          <span className="text-sm text-gray-400">{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Additional Capabilities */}
      <section className="pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">
            Additional Capabilities
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {additionalCapabilities.map((cap, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-5"
              >
                <cap.icon className="w-4 h-4 text-emerald-400 mb-3" />
                <h4 className="text-sm font-semibold text-white mb-1">{cap.title}</h4>
                <p className="text-xs text-gray-500 leading-relaxed">{cap.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}