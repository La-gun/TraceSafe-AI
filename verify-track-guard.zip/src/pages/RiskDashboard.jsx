import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import Navbar from "../components/landing/Navbar";
import NigeriaHeatmap from "../components/risk/NigeriaHeatmap";
import BatchDetailModal from "../components/risk/BatchDetailModal";
import DraftManager from "../components/risk/DraftManager";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldAlert, Layers, FileEdit, RefreshCw } from "lucide-react";
import usePullToRefresh from "@/hooks/usePullToRefresh.jsx";

const TABS = [
  { id: "map",    label: "Risk Heatmap",    icon: Layers },
  { id: "drafts", label: "Draft Reports",   icon: FileEdit },
];

export default function RiskDashboard() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("map");
  const [selectedLocation, setSelectedLocation] = useState(null); // { state, batches[] }
  const { containerRef, PullIndicator } = usePullToRefresh(() =>
    queryClient.invalidateQueries()
  );

  const { data: batches = [], isLoading: batchesLoading } = useQuery({
    queryKey: ["risk-batches"],
    queryFn: () => base44.entities.Batch.list("-diversion_score", 200),
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ["risk-alerts"],
    queryFn: () => base44.entities.DiversionAlert.list("-created_date", 200),
  });

  // Summarise risk stats
  const highRisk  = batches.filter((b) => (b.diversion_score || 0) >= 75).length;
  const medRisk   = batches.filter((b) => (b.diversion_score || 0) >= 40 && (b.diversion_score || 0) < 75).length;
  const recalled  = batches.filter((b) => b.enforcement_status === "recalled").length;
  const openAlerts= alerts.filter((a) => a.status === "open").length;

  return (
    <div ref={containerRef} className="min-h-screen bg-[#060B18] overflow-y-auto">
      <PullIndicator />
      <Navbar />

      {/* Header */}
      <section className="pt-32 pb-6 px-6 relative overflow-hidden">
        <div className="absolute top-0 right-1/4 w-[500px] h-[300px] bg-red-500/4 rounded-full blur-[120px]" />
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-red-400 tracking-widest uppercase">Inspector Module</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white">Risk Dashboard</h1>
              </div>
            </div>
            <button
              onClick={() => queryClient.invalidateQueries()}
              className="flex items-center gap-2 text-xs text-gray-400 hover:text-white border border-white/[0.08] rounded-full px-3 py-1.5 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh
            </button>
          </div>
          <p className="text-gray-400 text-sm mt-2 max-w-2xl">
            Geospatial risk intelligence across Nigeria. Colour-coded by diversion score and alert frequency.
          </p>
        </div>
      </section>

      {/* Stats strip */}
      <div className="px-6 pb-5">
        <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "High Risk Batches",  value: highRisk,   color: "text-red-400",    bg: "bg-red-500/10 border-red-500/20" },
            { label: "Medium Risk",        value: medRisk,    color: "text-amber-400",  bg: "bg-amber-500/10 border-amber-500/20" },
            { label: "Active Recalls",     value: recalled,   color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/20" },
            { label: "Open Alerts",        value: openAlerts, color: "text-blue-400",   bg: "bg-blue-500/10 border-blue-500/20" },
          ].map(({ label, value, color, bg }) => (
            <div key={label} className={`border rounded-2xl px-4 py-3 ${bg}`}>
              <p className={`text-[10px] uppercase tracking-wider font-medium ${color} mb-1`}>{label}</p>
              <p className={`text-2xl font-bold ${color}`}>{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 pb-4">
        <div className="max-w-7xl mx-auto flex gap-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all border ${
                activeTab === tab.id
                  ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400"
                  : "border-white/[0.06] text-gray-500 hover:text-gray-300"
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="px-6 pb-24">
        <div className="max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === "map" && (
                <NigeriaHeatmap
                  batches={batches}
                  alerts={alerts}
                  isLoading={batchesLoading}
                  onLocationSelect={setSelectedLocation}
                />
              )}
              {activeTab === "drafts" && <DraftManager />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Batch detail modal */}
      <AnimatePresence>
        {selectedLocation && (
          <BatchDetailModal
            locationData={selectedLocation}
            onClose={() => setSelectedLocation(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}