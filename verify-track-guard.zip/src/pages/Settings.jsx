import React from "react";
import Navbar from "../components/landing/Navbar";
import Footer from "../components/landing/Footer";
import AccountDeletion from "../components/AccountDeletion";
import { Settings as SettingsIcon, User, Bell, Lock } from "lucide-react";

const SECTIONS = [
  { icon: User,  title: "Profile",       desc: "Manage your name and contact details" },
  { icon: Bell,  title: "Notifications", desc: "Configure alert and email preferences" },
  { icon: Lock,  title: "Security",      desc: "Password, 2FA, and session management" },
];

export default function Settings() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      <section className="pt-32 pb-10 px-6 relative">
        <div className="absolute top-0 right-1/3 w-[400px] h-[300px] bg-emerald-500/4 rounded-full blur-[100px]" />
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center">
              <SettingsIcon className="w-5 h-5 text-gray-400" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">Settings</h1>
          </div>
          <p className="text-gray-500 text-sm">Manage your account and application preferences.</p>
        </div>
      </section>

      <section className="px-6 pb-10">
        <div className="max-w-3xl mx-auto space-y-3">
          {SECTIONS.map((s, i) => (
            <div key={i} className="flex items-center gap-4 bg-white/[0.02] border border-white/[0.06] rounded-2xl px-5 py-4 hover:border-white/[0.10] transition-colors cursor-pointer min-h-[64px]">
              <div className="w-9 h-9 rounded-xl bg-white/[0.04] flex items-center justify-center shrink-0">
                <s.icon className="w-4 h-4 text-gray-400" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">{s.title}</p>
                <p className="text-xs text-gray-500">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Danger Zone */}
      <section className="px-6 pb-24">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-xs font-medium text-gray-600 uppercase tracking-widest mb-3">Danger Zone</h2>
          <AccountDeletion />
        </div>
      </section>

      <Footer />
    </div>
  );
}