import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Smartphone, Scan, ShieldCheck, AlertTriangle, XCircle,
  MapPin, Clock, Factory, Ship, Warehouse, Store, User,
  ChevronRight, ArrowLeft, Wifi, WifiOff, RotateCcw, Shield,
  TrendingUp, Package, FileEdit, Sparkles
} from "lucide-react";
import useOfflineSync, { getCachedProduct, setCachedProduct } from "@/hooks/useOfflineSync";
import OfflineBanner from "@/components/inspector/OfflineBanner";
import OfflineDraftForm from "@/components/inspector/OfflineDraftForm";
import InspectorAIChat from "@/components/inspector/InspectorAIChat";

// ── Mock product database (also seeded into the local cache on first use) ──
const PRODUCT_DATABASE = {
  "04:A3:F2:12:8B:4C:80": {
    uid: "04:A3:F2:12:8B:4C:80",
    product: "Amoxicillin 500mg Capsules",
    brand: "PharmaNig Ltd.",
    batch: "AMX-2026-0341",
    serial: "NG-PH-00041872",
    manufactured: "Jan 2026",
    expiry: "Dec 2027",
    status: "hold",
    diversion_score: 87,
    diversion_flags: ["geo_mismatch", "out_of_zone"],
    chain: [
      { stage: "Manufacture",        icon: Factory,   date: "14 Jan 2026", location: "Lagos — PharmaNig Plant A",       status: "ok" },
      { stage: "Port of Entry",      icon: Ship,      date: "28 Jan 2026", location: "Apapa Port, Lagos",               status: "ok" },
      { stage: "Wholesale Transfer", icon: Warehouse, date: "03 Feb 2026", location: "Lagos — MedDist Wholesale",       status: "ok" },
      { stage: "Retail Receipt",     icon: Store,     date: "18 Mar 2026", location: "Onitsha, Anambra ⚠ Out of Zone", status: "warn" },
    ],
    alert: "Product detected 480 km outside authorised Lagos distribution zone. Hold applied pending investigation.",
  },
  "04:B7:C1:09:2D:5E:91": {
    uid: "04:B7:C1:09:2D:5E:91",
    product: "Metformin 850mg Tablets",
    brand: "CurePharm Nigeria",
    batch: "MET-2026-0112",
    serial: "NG-CP-00029401",
    manufactured: "Nov 2025",
    expiry: "Oct 2027",
    status: "active",
    diversion_score: 22,
    diversion_flags: [],
    chain: [
      { stage: "Manufacture",        icon: Factory,   date: "08 Nov 2025", location: "Abuja — CurePharm Plant",       status: "ok" },
      { stage: "Port of Entry",      icon: Ship,      date: "20 Nov 2025", location: "Tin Can Port, Lagos",           status: "ok" },
      { stage: "Wholesale Transfer", icon: Warehouse, date: "30 Nov 2025", location: "Kano — Northern Dist. Hub",     status: "ok" },
      { stage: "Retail Receipt",     icon: Store,     date: "10 Dec 2025", location: "Kano Central Pharmacy",         status: "ok" },
      { stage: "End-User Verify",    icon: User,      date: "18 Mar 2026", location: "Kano — Patient Tap",            status: "ok" },
    ],
    alert: null,
  },
  "04:C9:D4:33:7A:1F:02": {
    uid: "04:C9:D4:33:7A:1F:02",
    product: "Artemether/Lumefantrine Tabs",
    brand: "TropicMed Ltd.",
    batch: "ART-2026-0023",
    serial: "NG-TM-00018834",
    manufactured: "Feb 2026",
    expiry: "Jan 2028",
    status: "recalled",
    diversion_score: 95,
    diversion_flags: ["unregistered_outlet", "recall_active", "geo_mismatch"],
    chain: [
      { stage: "Manufacture",        icon: Factory,   date: "02 Feb 2026", location: "Ogun — TropicMed Factory",               status: "ok" },
      { stage: "Port of Entry",      icon: Ship,      date: "14 Feb 2026", location: "Apapa Port, Lagos",                      status: "ok" },
      { stage: "Wholesale Transfer", icon: Warehouse, date: "22 Feb 2026", location: "FCT — Authorised Distributor",            status: "ok" },
      { stage: "Retail Receipt",     icon: Store,     date: "17 Mar 2026", location: "Mararaba, Nassarawa ⚠ Unregistered Outlet", status: "warn" },
    ],
    alert: "ACTIVE RECALL. Batch subject to national recall order. Do not dispense. Seize and report to NAFDAC immediately.",
  },
};

const DEMO_TAGS = [
  { label: "Tap: Amoxicillin (Hold)", uid: "04:A3:F2:12:8B:4C:80" },
  { label: "Tap: Metformin (Active)", uid: "04:B7:C1:09:2D:5E:91" },
  { label: "Tap: Artemether (Recall)", uid: "04:C9:D4:33:7A:1F:02" },
];

const statusConfig = {
  active:   { label: "Active",   bg: "bg-emerald-500/10", border: "border-emerald-500/30", text: "text-emerald-400", icon: ShieldCheck,    ring: "ring-emerald-500/20" },
  hold:     { label: "Hold",     bg: "bg-amber-500/10",   border: "border-amber-500/30",   text: "text-amber-400",   icon: AlertTriangle,  ring: "ring-amber-500/20" },
  recalled: { label: "RECALLED", bg: "bg-red-500/10",     border: "border-red-500/30",     text: "text-red-400",     icon: XCircle,        ring: "ring-red-500/30" },
};

const riskColor = (score) => {
  if (score >= 75) return { bar: "bg-red-500",    text: "text-red-400",    label: "High Risk" };
  if (score >= 40) return { bar: "bg-amber-500",  text: "text-amber-400",  label: "Medium Risk" };
  return               { bar: "bg-emerald-500", text: "text-emerald-400", label: "Low Risk" };
};

const flagLabels = {
  geo_mismatch: "Geo Mismatch",
  out_of_zone: "Out of Zone",
  recall_active: "Recall Active",
  unregistered_outlet: "Unregistered Outlet",
  repeat_scan: "Repeat Scan",
};

// ── Scan screen ──────────────────────────────────────────────────────────────
function ScanScreen({ onScan, isOnline }) {
  const [scanning, setScanning] = useState(false);

  const simulateTap = (uid) => {
    setScanning(true);
    setTimeout(() => { setScanning(false); onScan(uid); }, 1800);
  };

  return (
    <div className="flex flex-col items-center justify-between h-full px-6 pt-10 pb-10">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Shield className="w-5 h-5 text-emerald-400" />
          <span className="text-sm font-bold text-white tracking-wide">Inspector Portal</span>
          <div className="flex items-center gap-1 ml-2">
            {isOnline
              ? <><Wifi    className="w-3.5 h-3.5 text-emerald-400" /><span className="text-[10px] text-emerald-400">Online</span></>
              : <><WifiOff className="w-3.5 h-3.5 text-amber-400"  /><span className="text-[10px] text-amber-400">Offline</span></>
            }
          </div>
        </div>
        <p className="text-xs text-gray-500">NAFDAC Field Verification System</p>
        {!isOnline && (
          <p className="text-[10px] text-amber-400/70 mt-1">Cached products available · drafts save locally</p>
        )}
      </div>

      {/* Scan ring */}
      <div className="relative flex items-center justify-center">
        <div className={`absolute w-56 h-56 rounded-full border-2 transition-all duration-700 ${scanning ? "border-emerald-400/60 scale-110" : "border-white/[0.06]"}`} />
        <div className={`absolute w-44 h-44 rounded-full border transition-all duration-700 ${scanning ? "border-emerald-400/40 scale-105" : "border-white/[0.04]"}`} />
        <motion.div
          animate={scanning ? { scale: [1, 1.08, 1], opacity: [1, 0.7, 1] } : {}}
          transition={{ repeat: Infinity, duration: 1 }}
          className={`w-32 h-32 rounded-full flex flex-col items-center justify-center border-2 transition-colors ${scanning ? "bg-emerald-500/10 border-emerald-500/40" : "bg-white/[0.03] border-white/[0.08]"}`}
        >
          {scanning ? (
            <>
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                <RotateCcw className="w-7 h-7 text-emerald-400" />
              </motion.div>
              <p className="text-[10px] text-emerald-400 mt-1.5">Reading…</p>
            </>
          ) : (
            <>
              <Scan className="w-8 h-8 text-gray-400" />
              <p className="text-[10px] text-gray-500 mt-1.5">Ready</p>
            </>
          )}
        </motion.div>
      </div>

      <div className="w-full space-y-4">
        <p className="text-center text-xs text-gray-500">
          Hold your phone near an NFC product tag, or select a demo:
        </p>
        <div className="space-y-2">
          {DEMO_TAGS.map((tag) => (
            <button
              key={tag.uid}
              onClick={() => simulateTap(tag.uid)}
              disabled={scanning}
              aria-label={`Simulate NFC scan: ${tag.label}`}
              className="w-full flex items-center justify-between bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.06] hover:border-emerald-500/20 rounded-2xl px-4 py-3 transition-all disabled:opacity-40"
            >
              <div className="flex items-center gap-3">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span className="text-sm text-white">{tag.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-500" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Result screen ────────────────────────────────────────────────────────────
function ResultScreen({ product, isOnline, onBack, onRefreshPending }) {
  const status = statusConfig[product.status];
  const StatusIcon = status.icon;
  const risk = riskColor(product.diversion_score);
  const [chainOpen, setChainOpen] = useState(false);
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {/* Top bar */}
      <div className="sticky top-0 z-10 bg-[#060B18]/90 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-white/[0.05]">
        <button onClick={onBack} aria-label="Go back to scan screen" className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          Scan Again
        </button>
        <span className="text-xs font-mono text-gray-600">{product.uid}</span>
      </div>

      <div className="px-4 pt-5 pb-8 space-y-4">
        {/* Status card */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
          className={`rounded-3xl border p-5 ring-4 ${status.bg} ${status.border} ${status.ring}`}>
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${status.bg} border ${status.border}`}>
              <StatusIcon className={`w-6 h-6 ${status.text}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs font-bold tracking-widest uppercase ${status.text}`}>{status.label}</span>
                {product.status === "recalled" && <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />}
              </div>
              <p className="text-white font-bold leading-tight">{product.product}</p>
              <p className="text-xs text-gray-400 mt-0.5">{product.brand}</p>
            </div>
          </div>
          {product.alert && (
            <div className={`mt-4 rounded-xl p-3 text-xs leading-relaxed border ${product.status === "recalled" ? "bg-red-500/10 border-red-500/20 text-red-300" : "bg-amber-500/10 border-amber-500/20 text-amber-300"}`}>
              {product.alert}
            </div>
          )}
        </motion.div>

        {/* Product details */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}
          className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Product Details</h3>
          <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs">
            {[["Batch No.", product.batch], ["Serial", product.serial], ["Manufactured", product.manufactured], ["Expiry", product.expiry]].map(([k, v]) => (
              <div key={k}>
                <p className="text-gray-600">{k}</p>
                <p className="text-white font-medium mt-0.5 font-mono text-[11px]">{v}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Diversion risk */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.14 }}
          className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-gray-400" />
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Diversion Risk Score</h3>
            </div>
            <span className={`text-xl font-bold ${risk.text}`}>{product.diversion_score}<span className="text-xs font-normal text-gray-600">/100</span></span>
          </div>
          <div className="w-full h-2.5 bg-white/[0.06] rounded-full overflow-hidden mb-3">
            <motion.div initial={{ width: 0 }} animate={{ width: `${product.diversion_score}%` }}
              transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }} className={`h-full rounded-full ${risk.bar}`} />
          </div>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold ${risk.text}`}>{risk.label}</span>
            {product.diversion_flags.length > 0 && (
              <div className="flex flex-wrap gap-1 justify-end">
                {product.diversion_flags.map((flag) => (
                  <span key={flag} className="text-[9px] font-medium bg-red-500/10 text-red-400 border border-red-500/20 px-1.5 py-0.5 rounded-full">
                    {flagLabels[flag] || flag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </motion.div>

        {/* Supply chain history */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-white/[0.02] border border-white/[0.06] rounded-2xl overflow-hidden">
          <button
            onClick={() => setChainOpen(!chainOpen)}
            aria-expanded={chainOpen}
            aria-label={chainOpen ? "Collapse supply chain history" : "Expand supply chain history"}
            className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-gray-400" />
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Supply Chain History</h3>
              <span className="text-[10px] bg-white/[0.06] text-gray-400 px-1.5 py-0.5 rounded-full">{product.chain.length} events</span>
            </div>
            <ChevronRight className={`w-4 h-4 text-gray-500 transition-transform ${chainOpen ? "rotate-90" : ""}`} />
          </button>
          <AnimatePresence>
            {chainOpen && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
                className="overflow-hidden border-t border-white/[0.04]">
                <div className="px-4 py-3 space-y-0">
                  {product.chain.map((event, i) => {
                    const Icon = event.icon;
                    const isLast = i === product.chain.length - 1;
                    const isWarn = event.status === "warn";
                    return (
                      <div key={i} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 border ${isWarn ? "bg-amber-500/10 border-amber-500/30" : "bg-emerald-500/10 border-emerald-500/20"}`}>
                            <Icon className={`w-3 h-3 ${isWarn ? "text-amber-400" : "text-emerald-400"}`} />
                          </div>
                          {!isLast && <div className="w-px flex-1 bg-white/[0.06] my-1" />}
                        </div>
                        <div className="pb-4 flex-1 min-w-0">
                          <p className={`text-xs font-semibold ${isWarn ? "text-amber-400" : "text-white"}`}>{event.stage}</p>
                          <p className="text-[11px] text-gray-500 mt-0.5">{event.location}</p>
                          <p className="text-[10px] text-gray-600 flex items-center gap-1 mt-0.5">
                            <Clock className="w-2.5 h-2.5" />{event.date}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* File Report — inline offline-capable form */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.26 }}>
          {!showForm ? (
            <button
              onClick={() => setShowForm(true)}
              className="w-full flex items-center justify-center gap-2 bg-emerald-500/10 hover:bg-emerald-500/15 border border-emerald-500/25 hover:border-emerald-500/40 rounded-2xl py-4 transition-all text-emerald-400 text-sm font-medium"
            >
              <FileEdit className="w-4 h-4" />
              {isOnline ? "File Inspection Report" : "Save Draft Report (Offline)"}
            </button>
          ) : (
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl overflow-hidden">
              <div className="px-4 pt-4 pb-2 border-b border-white/[0.05]">
                <p className="text-sm font-semibold text-white">Inspection Report</p>
                <p className="text-[10px] text-gray-500 mt-0.5">{isOnline ? "Will submit immediately" : "Will save offline and auto-sync"}</p>
              </div>
              <OfflineDraftForm
                prefillProduct={product}
                isOnline={isOnline}
                onClose={() => setShowForm(false)}
                onRefreshPending={onRefreshPending}
              />
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

// ── Main page ────────────────────────────────────────────────────────────────
export default function InspectorPortal() {
  const [scannedProduct, setScannedProduct] = useState(null);
  const [activeTab, setActiveTab] = useState("scan"); // "scan" | "ai"
  const { isOnline, pendingCount, syncing, lastSyncedAt, syncPendingDrafts, refreshPendingCount } = useOfflineSync();

  const handleScan = (uid) => {
    let product = PRODUCT_DATABASE[uid] ?? getCachedProduct(uid);
    if (product) setCachedProduct(uid, PRODUCT_DATABASE[uid] ?? product);
    setScannedProduct(product || null);
  };

  return (
    <div className="min-h-screen bg-[#060B18] flex flex-col items-center justify-start">
      <div className="w-full max-w-sm min-h-screen sm:min-h-0 sm:my-8 sm:rounded-[2.5rem] sm:border sm:border-white/[0.08] sm:shadow-2xl bg-[#060B18] overflow-hidden flex flex-col relative" style={{ minHeight: "calc(100vh - 0px)" }}>

        {/* Simulated status bar (desktop only) */}
        <div className="hidden sm:flex items-center justify-between px-6 pt-4 pb-1">
          <span className="text-[10px] text-gray-600">09:41</span>
          <div className="flex items-center gap-1.5">
            {isOnline ? <Wifi className="w-3 h-3 text-gray-600" /> : <WifiOff className="w-3 h-3 text-amber-600" />}
            <div className="flex gap-0.5">
              {[3, 4, 5].map(h => <div key={h} className="w-0.5 bg-gray-600 rounded-sm" style={{ height: h }} />)}
            </div>
          </div>
        </div>

        {/* Back link */}
        <div className="px-4 py-2 border-b border-white/[0.04]">
          <Link to="/Enforcement" className="text-[10px] text-gray-600 hover:text-gray-400 flex items-center gap-1 transition-colors">
            <ArrowLeft className="w-3 h-3" />
            Back to Enforcement Console
          </Link>
        </div>

        {/* Tab switcher */}
        <div className="flex gap-1 px-4 pt-3 pb-1 shrink-0">
          <button
            onClick={() => { setActiveTab("scan"); setScannedProduct(null); }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium transition-colors ${
              activeTab === "scan"
                ? "bg-emerald-500/15 border border-emerald-500/30 text-emerald-400"
                : "text-gray-500 hover:text-gray-300 border border-transparent"
            }`}
          >
            <Scan className="w-3.5 h-3.5" />
            NFC Scan
          </button>
          <button
            onClick={() => setActiveTab("ai")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium transition-colors ${
              activeTab === "ai"
                ? "bg-violet-500/15 border border-violet-500/30 text-violet-400"
                : "text-gray-500 hover:text-gray-300 border border-transparent"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Inspector AI
          </button>
        </div>

        {/* Offline banner (scan tab only) */}
        {activeTab === "scan" && (
          <OfflineBanner
            isOnline={isOnline}
            pendingCount={pendingCount}
            syncing={syncing}
            lastSyncedAt={lastSyncedAt}
            onManualSync={syncPendingDrafts}
          />
        )}

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          <AnimatePresence mode="wait">
            {activeTab === "ai" ? (
              <motion.div key="ai" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full flex flex-col">
                <InspectorAIChat />
              </motion.div>
            ) : !scannedProduct ? (
              <motion.div key="scan" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="h-full">
                <ScanScreen onScan={handleScan} isOnline={isOnline} />
              </motion.div>
            ) : (
              <motion.div key="result" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="h-full">
                <ResultScreen
                  product={scannedProduct}
                  isOnline={isOnline}
                  onBack={() => setScannedProduct(null)}
                  onRefreshPending={refreshPendingCount}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}